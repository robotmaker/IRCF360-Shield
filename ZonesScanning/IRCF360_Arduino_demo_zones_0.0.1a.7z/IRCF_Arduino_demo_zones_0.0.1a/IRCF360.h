/*
  IRCF360_CONFIG.h - Library for 360 degree proximity sensing.
  Created by Colin Bacon, Feb 2, 2018.
  Released into the public domain.
*/
//The main construct wrapper
#ifndef ICRF360_h
    #define ICRF360_h
    #include "Arduino.h" 

class IRCF360 {
   public:
     //Constructor
    IRCF360(int dummy=0);

     //Methods
    void flashLED(int directions,int durations);
    void flashIRLED(int directions,int durations);
   
   private:
   int _duration;  
};  
    
#define  BOARD ATmega328      // such as NANO Arduino Boards
#if  (BOARD==ATmega328)  
    //LED DDRB Defintions     BXX543210
    #define  LED_N_DDRB       B00110000;  //LED_N   (PB4+PB5)
    #define  LED_NE_DDRB      B00110000;  //LED_NE  (PB5+PB4)
    #define  LED_E_DDRB       B00101000;  //LED_E   (PB5+PB3)
    #define  LED_SE_DDRB      B00101000;  //LED_SE  (PB3+PB5)
    #define  LED_S_DDRB       B00100010;  //LED_S   (PB1+PB5)
    #define  LED_SW_DDRB      B00010010;  //LED_SW  (PB4+PB1)
    #define  LED_W_DDRB       B00011000;  //LED_W   (PB3+PB4)
    #define  LED_NW_DDRB      B00011000;  //LED_NW  (PB4+PB3)
   
    //LED PORTB Defintions    BXX543210; //visible LED's
    #define  LED_N_ON         B00010000; //N        (PB4)
    #define  LED_NE_ON        B00100000; //NE       (PB5)
    #define  LED_E_ON         B00100000; //E        (PB5)
    #define  LED_SE_ON        B00001000; //SE       (PB3)
    #define  LED_S_ON         B00000010; //S        (PB1)
    #define  LED_SW_ON        B00010000; //SW       (PB5)
    #define  LED_W_ON         B00001000; //W        (PB3)
    #define  LED_NW_ON        B00010000; //NW       (PB4 )
    #define  LED_OFF          B00000000; //ALL_OFF
    
    //IRLED DDRB Defintions   BXX543210                                       
    
    #define  IRLED_N_DDRB     B00010010; //IR_N   (PB4+PB1)
    #define  IRLED_NE_DDRB    B00000101; //IR_NE  (PB2+PB4)
    #define  IRLED_E_DDRB     B00000110; //IR_E   (PB2+PB4)
    #define  IRLED_SE_DDRB    B00001010; //IR_SE  (PB1+PB3)
    #define  IRLED_S_DDRB     B00001010; //IR_S   (PB1+PB3)
    #define  IRLED_SW_DDRB    B00100010; //IR_SW  (PB5+PB1)
    #define  IRLED_W_DDRB     B00001100; //IR_W   (PB2+PB4)
    #define IRLED_NW_DDRB     B00100100; //IR_NW  (RB3+RB7)
    
  
    //IRLED PORT Defintions  B76543210 ;           
    #define  IRLED_N_ON      B00000010 ; //IR_NORTH (RB1).  
    #define  IRLED_NE_ON     B00000100 ; //IR_NE (RB1). 
    #define  IRLED_E_ON      B00000100 ; //IR_E  (RB2)
    #define  IRLED_SE_ON     B00001000 ; //IR_SE (PB3)
    #define  IRLED_S_ON      B00000010 ; //IR_S  (PB1)
    #define  IRLED_SW_ON     B00100000 ; //IR_SW (PB5 )
    #define  IRLED_W_ON      B00000100 ; //IR_W  (PB2 )
    #define  IRLED_NW_ON     B00000100 ; //IR NW (PB2)
    #define  IRLED_OFF       B00000000; //ALL
#endif


 

#endif
