/*
  IRCF360_PING.cpp - Library for 360 degree proximity sensing.
  Created by Colin Bacon, Feb 2, 2018.
  Released into the public domain.
*/
#include "Arduino.h"
#include "IRCF360_PING.h"
#include "IRCF360.h"
int pulsewidth;
 IRCF360_PING::IRCF360_PING(int dummy2){
  
 
}

void IRCF360_PING::ping(int ZONE) {
    
   switch (ZONE){
    case 1: pulsewidth=12;
    break;

    case 2: pulsewidth=13;
    break;
    
    case 3: pulsewidth=14;
    break;
    
    case 4: pulsewidth=15;
    break;
   
   default: pulsewidth=14;
    break;
   } 
    
    for (int ii=1; ii <= 100; ii++){
         //IR 38MHZ modulation wave
         for (int i=1; i <= 16; i++){
         DDRB =  LED_N_DDRB;
         PORTB = LED_N_ON;
         delayMicroseconds(pulsewidth);
        asm ( 
            "nop \n"
            "nop \n"
            "nop \n"
         );
         PORTB = LED_OFF;
         delayMicroseconds(pulsewidth);
          asm ( 
            "nop \n"
            "nop \n"
            "nop \n"
         );
         
         };
          delayMicroseconds(1500);
    }
}
