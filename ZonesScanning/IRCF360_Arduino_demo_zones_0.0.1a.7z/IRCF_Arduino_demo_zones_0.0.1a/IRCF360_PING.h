/*
  IRCF360_PING.h - Library for 360 degree proximity sensing.
  Created by Colin Bacon, Feb 2, 2018.
  Released into the public domain.
*/
//The main construct wrapper
#ifndef ICRF360_PING_h
    #define ICRF360_PING_h
    #include "Arduino.h" 

class IRCF360_PING {
   public:
     //Constructor
    IRCF360_PING(int dummy2=0);

     //Methods
    void ping(int ZONE);
    
   
   private:
   int _duration2;  
};  

#endif
