/*
  IRCF360_CONFIG.cpp - Library for 360 degree proximity sensing.
  Created by Colin Bacon, Feb 2, 2018.
  Released into the public domain.
*/
#include "Arduino.h"
#include "IRCF360.h"

 IRCF360::IRCF360(int dummy){
  
 
}
 
 
void IRCF360::flashLED(int directions, int durations)
{ 
  switch (directions){
    case 1:
      DDRB =  LED_N_DDRB;
      PORTB = LED_N_ON;
      break;

   case 2:
      DDRB =  LED_NE_DDRB;
      PORTB = LED_NE_ON;
       break;

    case 3:
      DDRB =  LED_E_DDRB;
      PORTB = LED_E_ON;
      break;

     case 4:
      DDRB =  LED_SE_DDRB;
      PORTB = LED_SE_ON;
      break;

     case 5:
      DDRB =  LED_S_DDRB;
      PORTB = LED_S_ON;
      break;

      case 6:
      DDRB =  LED_SW_DDRB;
      PORTB = LED_SW_ON;
      break;

      case 7:
      DDRB =  LED_W_DDRB;
      PORTB = LED_W_ON;
      break;

      case 8:
      DDRB =  LED_NW_DDRB;
      PORTB = LED_NW_ON;
      break;

      default:
      DDRB =  LED_N_DDRB;
      PORTB = LED_N_ON;
      break;
    
    }
      delay(durations/2);                        // wait for a period
      PORTB = LED_OFF;
      delay(durations/2);                        // wait for a period
    
}


void IRCF360::flashIRLED(int directions, int durations)
{
  switch (directions){
    case  1:  
        DDRB =  IRLED_N_DDRB;
        PORTB = IRLED_N_ON ;                        
        break;

     case 2:
        DDRB =  IRLED_NE_DDRB;
        PORTB = IRLED_NE_ON;
        break;  

     case 3:
        DDRB =  IRLED_E_DDRB;
        PORTB = IRLED_E_ON;
        break;  

     case 4:
        DDRB =  IRLED_SE_DDRB;
        PORTB = IRLED_SE_ON;
        break;  

     case 5:
        DDRB =  IRLED_S_DDRB;
        PORTB = IRLED_S_ON;
        break; 

    case 6:
        DDRB =  IRLED_SW_DDRB;
        PORTB = IRLED_SW_ON;
        break; 

    case 7:
        DDRB =  IRLED_W_DDRB;
        PORTB = IRLED_W_ON;
        break; 

    case 8:
        DDRB =  IRLED_NW_DDRB;
        PORTB = IRLED_NW_ON;
        break; 

     default:
      DDRB =  IRLED_N_DDRB;
      PORTB = IRLED_N_ON;
      break;
      }

      delay(durations/2);  // wait for a period
      PORTB = IRLED_OFF;                      
      delay(durations/2); // wait for a period
        
}
